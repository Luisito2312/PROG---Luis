package EjercicioClase;

public interface Tarea {
    
    //Metodos
    public static void añadir(Alumno alumno) {

    }

    public static void listar() {

    }

    public static void editar(Alumno alumno) {

    }

    public static void borrar(Alumno alumno) {
        
    }
}
